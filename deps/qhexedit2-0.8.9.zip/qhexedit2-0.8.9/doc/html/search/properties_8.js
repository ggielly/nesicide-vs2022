var searchData=
[
  ['selectioncolor',['selectionColor',['../class_q_hex_edit.html#ac0b628f34316aff9e18fc73a738250d7',1,'QHexEdit']]]
];
