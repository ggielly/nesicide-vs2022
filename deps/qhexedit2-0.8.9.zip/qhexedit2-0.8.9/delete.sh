sudo rm -f /usr/lib/libqhexedit*

# Python 2
sudo rm -f /usr/local/lib/python2.7/dist-packages/qhexedit*
sudo rm -f /usr/local/lib/python2.7/dist-packages/QHexEdit*

# Python 3
sudo rm -f /usr/local/lib/python3.4/dist-packages/qhexedit.cpython-34m.so
sudo rm -f /usr/local/lib/python3.4/dist-packages/QHexEdit-0.7.2.egg-info

sudo rm -f -R build

mkdir build
