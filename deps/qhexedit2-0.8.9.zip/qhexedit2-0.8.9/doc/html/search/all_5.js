var searchData=
[
  ['font',['font',['../class_q_hex_edit.html#a9579dc7273c48b89c9e4f26adda78671',1,'QHexEdit']]]
];
